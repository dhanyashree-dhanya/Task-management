export type Status = "in-progress" | "review" | "completed";

export interface Todo {
  id: number;
  title: string;
  description: string;
  status: Status;
}
import { useState } from "react";
import type { Todo } from "./types/index";
import TodoList from "./components/TodoList";
import AddTodo from "./components/AddTodo";
import "./styles.css";

function App() {
  const [view, setView] = useState<"listView" | "addView">("listView");
  const [editingTodo, setEditingTodo] = useState<Todo | null>(null);
  const [todos, setTodos] = useState<Todo[]>([
    // {
    //   id: 1,
    //   title: "Lorem Ipsum",
    //   description: "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
    //   status: "in-progress",
    // },
    // {
    //   id: 2,
    //   title: "Lorem Ipsum",
    //   description: " description lorem ipsum dolor sit amet, consectetur adipiscing elit.",
    //   status: "in-progress",
    // },
    // {
    //   id: 2,
    //   title: "TODO Item 2",
    //   description: "Sample description lorem ipsum dolor sit amet, consectetur adipiscing elit.",
    //   status: "completed",
    // },
    // {
    //   id: 3,
    //   title: "TODO Item 3",
    //   description: "Sample description lorem ipsum dolor sit amet, consectetur adipiscing elit.",
    //   status: "review",
    // },
  ]);

  const addTodo = (todo: Omit<Todo, "id">) => {
    setTodos((prev) => [
      ...prev,
      { ...todo, id: Date.now() },
    ]);
    setEditingTodo(null);
    setView("listView");
  };

  const updateTodo = (todo: Todo) => {
    setTodos((prev) => prev.map((t) => (t.id === todo.id ? todo : t)));
    setEditingTodo(null);
    setView("listView");
  };

  const onEditTodo = (todo: Todo) => {
    setEditingTodo(todo);
    setView("addView");
  };

  return (
    <div className="container">
      {view === "listView" ? (
        <TodoList
          todoList={todos}
          onAddClick={() => {
            setEditingTodo(null);
            setView("addView");
          }}
          onEditTodo={onEditTodo}
        />
      ) : (
        <AddTodo
          onCancel={() => {
            setEditingTodo(null);
            setView("listView");
          }}
          onAdd={addTodo}
          onSave={updateTodo}
          editingTodo={editingTodo}
        />
      )}
    </div>
  );
}

export default App




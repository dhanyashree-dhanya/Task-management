import { useState, useEffect, useRef } from "react";
import type { Status, Todo } from "../types/index";
import '../styles.css';
import AppTitle from './AppTitle'
import dropdownIcon from "../assets/Vector.png";

interface Props {
  onCancel: () => void;
  onAdd: (todo: {
    title: string;
    description: string;
    status: Status;
  }) => void;
  onSave: (todo: {
    id: number;
    title: string;
    description: string;
    status: Status;
  }) => void;
  editingTodo: Todo | null;
}

const STATUS_OPTIONS: Array<{ value: Status; label: string; color: string }> = [
{ value: "review", label: "Pending", color: "#D0D0D0" },
  { value: "in-progress", label: "In Progress", color: "#FFB03C" },
  { value: "completed", label: "Completed", color: "#34A853" },
];

const AddTodo: React.FC<Props> = ({ onCancel, onAdd, onSave, editingTodo }) => {
  const [title, setTitle] = useState(editingTodo?.title ?? "");
  const [description, setDescription] = useState(editingTodo?.description ?? "");
  const [status, setStatus] = useState<Status>(editingTodo?.status ?? "in-progress");
  const [isStatusOpen, setIsStatusOpen] = useState(false);
  const statusSelectRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        statusSelectRef.current &&
        !statusSelectRef.current.contains(event.target as Node)
      ) {
        setIsStatusOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  useEffect(() => {
    if (editingTodo) {
      setTitle(editingTodo.title);
      setDescription(editingTodo.description);
      setStatus(editingTodo.status);
    } else {
      setTitle("");
      setDescription("");
      setStatus("in-progress");
    }
  }, [editingTodo]);

  const handleSubmit = () => {
    if (!title.trim() || !description.trim()) {
      return;
    }

    if (editingTodo) {
      onSave({
        id: editingTodo.id,
        title: title.trim(),
        description: description.trim(),
        status,
      });
    } else {
      onAdd({
        title: title.trim(),
        description: description.trim(),
        status,
      });
    }
  };

  return (
    <div className="panel">
      <AppTitle 
        title={editingTodo ? "Edit Task" : "Add Task"} 
        backButton={true} 
        onBackClick={() => {
          onCancel();
        }} 
      />

      <input
        placeholder="Enter the title"
        value={title}
        className="inputAddNew"
        onChange={(e) => setTitle(e.target.value)}
      />

      <textarea
        placeholder="Enter the description"
        value={description}
        onChange={(e) => setDescription(e.target.value)}
      />

      <div className="status-select-wrap">
        <div className="custom-select" ref={statusSelectRef}>
          <button
            type="button"
            className="custom-select-trigger"
            onClick={() => setIsStatusOpen((s) => !s)}
          >
            <div style={{display:"flex", flexDirection:"row", gap:"8px"}}>
            <div
              className="status-badge"
              style={{
                background: STATUS_OPTIONS.find((x) => x.value === status)?.color,
              }}
            />
            <div>{STATUS_OPTIONS.find((x) => x.value === status)?.label}</div>
            </div>
            <div className={isStatusOpen ? "dropdown-icon open" : "dropdown-icon"}>
              <img src={dropdownIcon} alt="Toggle dropdown" />
            </div>
          </button>

          {isStatusOpen && (
            <ul className="custom-options">
              {STATUS_OPTIONS.map((option) => (
                <li key={option.value}>
                  <button
                    type="button"
                    className={`custom-option ${status === option.value ? "selected" : ""}`}
                    onClick={() => {
                      setStatus(option.value);
                      setIsStatusOpen(false);
                    }}
                  >
                    <span className="status-badge" style={{ background: option.color }} />
                    {option.label}
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>

      <div className="buttonWrap">
        <button 
          className="secondaryBtn"
          onClick={onCancel}
        >
          Cancel
        </button>

        <button
          className="primaryBtn"
          onClick={handleSubmit}
        >
          {editingTodo ? "Update" : "Add"}
        </button>
      </div>
    </div>
  );
};

export default AddTodo;